<?php
/**
 *
 * @ Author Name  : DoiZece
 * @ Release on : 2014-12-28
 * @ Author Website  : http://www.buxsense.ro
 *
 **/

error_reporting(E_ALL & ~E_NOTICE);
define("LicenseNumber", "EvolutionScript Ultimate 5.1 BY BuxSense");
?>