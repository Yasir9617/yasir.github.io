<?php
/**
 *
 * @ EvolutionScript FULL DECODED & NULLED
 *
 * @ Version  : 5.0
 * @ Author   : BuxSense
 * @ Release on : 2014-08-15
 * @ Website  : http://www.buxsense.ro
 *
 **/

include INCLUDES . "plugins/phpfastcache/phpfastcache.php";
phpFastCache::setup("storage", "files");
phpFastCache::setup("path", INCLUDES . "cache/");
$cache = phpFastCache();
?>