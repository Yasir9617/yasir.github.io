<?php
/**
 *
 * @ Author Name  : DoiZece
 * @ Release on : 2014-12-28
 * @ Author Website  : http://www.buxsense.ro
 *
 **/

if (!defined("EvolutionScript")) {
	exit("Hacking attempt...");
}
/*
$chkadmin = new VData();
$localkey = $db->fetchOne("SELECT localkey FROM localkey WHERE id=1");
$chkadmin->getinfo($localkey);
$chkadmin->validate($ptcevolution->config['Misc']['license']);

if ($chkadmin->checkstatus !== true) {
}*/

?>