<?php
/**
 *
 * @ Author Name  : DoiZece
 * @ Release on : 2014-12-28
 * @ Author Website  : http://www.buxsense.ro
 *
 **/

if (!defined("EvolutionScript")) {
	exit("Hacking attempt...");
}

echo "

</div>

	<div class=\"footer\">
    	<div  align=\"center\">Powered by PtcBestMaker Version ";
echo "&copy;  ";
echo date("Y");
echo " PtcBestMaker.com</div>

        <div class=\"clear\"></div>
	</div>
</div>


</body>
</html>
    ";
?>