<?php
/**
 *
 * @ EvolutionScript FULL DECODED & NULLED
 *
 * @ Version  : 5.1
 * @ Author   : BuxSense
 * @ Release on : 2014-12-28
 * @ Website  : http://www.buxsense.ro
 *
 **/

if (!defined("EvolutionScript")) {
	exit("Hacking attempt...");
}

$package = $db->fetchOne("SELECT refs FROM referral_price WHERE id=" . $order['item_id']);
$countrefs = referralsleft($order['user_id']);

if ($package <= $countrefs) {
	addboughtmembers($order['user_id'], $package);
	return 1;
}

$error_msg = "There is not enough referrals to add.";
?>