<?php
/**
 *
 * @ EvolutionScript FULL DECODED & NULLED
 *
 * @ Version  : 5.1
 * @ Author   : BuxSense
 * @ Release on : 2014-12-28
 * @ Website  : http://www.buxsense.ro
 *
 **/

if (!defined("EvolutionScript")) {
	exit("Hacking attempt...");
}

$credits = $db->fetchOne("SELECT credits FROM ads_price WHERE id=" . $order['item_id']);
addptccredits($order['user_id'], $credits);
?>