<?php
/**
 *
 * @ EvolutionScript FULL DECODED & NULLED
 *
 * @ Version  : 5.1
 * @ Author   : BuxSense
 * @ Release on : 2014-12-28
 * @ Website  : http://www.buxsense.ro
 *
 **/

if (!defined("EvolutionScript")) {
	exit("Hacking attempt...");
}

$countrefs = rentedreferralsleft($order['user_id']);

if ($order['item_id'] <= $countrefs) {
	$rentaction = addrentreferrals($order['user_id'], $order['item_id']);
	return 1;
}

$error_msg = "There is not enough referrals to add.";
?>