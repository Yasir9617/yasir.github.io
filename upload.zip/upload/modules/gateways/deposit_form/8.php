<?php
/**
 *
 * @ EvolutionScript FULL DECODED & NULLED
 *
 * @ Version  : 5.1
 * @ Author   : BuxSense
 * @ Release on : 2014-12-28
 * @ Website  : http://www.buxsense.ro
 *
 **/

if (!defined("EvolutionScript")) {
	exit("Hacking attempt...");
}

$processor_form = "
<form action=\"./?view=blockchain\" method=\"post\" id=\"checkout[id]\">
<input type=\"hidden\" name=\"decription\" value=\"[itemname]\">
<input type=\"hidden\" name=\"amount\" id=\"amount[id]\" value=\"[price]\">
<input type=\"hidden\" name=\"type\" value=\"deposit\">
</form>
";
?>