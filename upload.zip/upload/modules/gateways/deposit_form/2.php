<?php
/**
 *
 * @ EvolutionScript FULL DECODED & NULLED
 *
 * @ Version  : 5.1
 * @ Author   : BuxSense
 * @ Release on : 2014-12-28
 * @ Website  : http://www.buxsense.ro
 *
 **/

if (!defined("EvolutionScript")) {
	exit("Hacking attempt...");
}

$processor_form = "
<form action=\"https://www.paypal.com/cgi-bin/webscr\" method=\"post\" id=\"checkout[id]\">
<input type=\"hidden\" name=\"cmd\" value=\"_xclick\">
<input type=\"hidden\" name=\"business\" value=\"[merchant]\">
<input type=\"hidden\" name=\"item_name\" value=\"[itemname]\">
<input type=\"hidden\" name=\"item_number\" value=\"[userid]\">
<input type=\"hidden\" name=\"currency_code\" value=\"[currency]\">
<input type=\"hidden\" value=\"1\" name=\"no_note\"/>
<input type=\"hidden\" value=\"1\" name=\"no_shipping\"/>
<input type=\"hidden\" name=\"amount\" id=\"amount[id]\" value=\"[price]\">
<input type=\"hidden\" name=\"return\" value=\"[site_url]modules/gateways/thankyou.php\">
<input type=\"hidden\" name=\"cancel_return\" value=\"[site_url]modules/gateways/addfunds.php\">
<input type=\"hidden\" name=\"notify_url\" value=\"[site_url]modules/gateways/ppstatus.php\">
</form>
";
?>