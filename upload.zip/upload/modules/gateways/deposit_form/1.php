<?php
/**
 *
 * @ EvolutionScript FULL DECODED & NULLED
 *
 * @ Version  : 5.1
 * @ Author   : BuxSense
 * @ Release on : 2014-12-28
 * @ Website  : http://www.buxsense.ro
 *
 **/

if (!defined("EvolutionScript")) {
	exit("Hacking attempt...");
}

$processor_form = "
<form method=\"post\" action=\"https://secure.payza.com/checkout\" id=\"checkout[id]\" >
<input type=\"hidden\" name=\"ap_purchasetype\" value=\"service\"/>
<input type=\"hidden\" name=\"ap_merchant\" value=\"[merchant]\"/>
<input type=\"hidden\" name=\"ap_itemname\" value=\"[itemname]\"/>
<input type=\"hidden\" name=\"ap_currency\" value=\"[currency]\"/>
<input type=\"hidden\" name=\"ap_returnurl\" value=\"[site_url]modules/gateways/thankyou.php\"/>
<input type=\"hidden\" name=\"ap_quantity\" value=\"1\"/>
<input type=\"hidden\" name=\"ap_description\" value=\"[itemname]\"/>
<input type=\"hidden\" name=\"ap_amount\" id=\"amount[id]\" value=\"[price]\"/>
<input type=\"hidden\" name=\"ap_cancelurl\" value=\"[site_url]modules/gateways/addfunds.php\"/>
<input type=\"hidden\" name=\"apc_1\" value=\"[userid]\"/>
<input type=\"hidden\"  name=\"ap_itemcode\" value=\"[itemname]\">
</form>
";
?>