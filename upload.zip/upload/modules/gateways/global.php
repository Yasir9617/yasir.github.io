<?php
/**
 *
 * @ EvolutionScript FULL DECODED & NULLED
 *
 * @ Version  : 5.1
 * @ Author   : BuxSense
 * @ Release on : 2014-12-28
 * @ Website  : http://www.buxsense.ro
 *
 **/

if (!defined("EvolutionScript")) {
	exit("Hacking attempt...");
}

define("INCLUDESPATH", dirname(dirname(dirname(__FILE__))) . "/includes/");
define("GATEWAYS", dirname(__FILE__) . "/");
require_once INCLUDESPATH . "global.php";
$query = $db->query("SELECT * FROM settings");

while ($result = $db->fetch_array($query)) {
	$settings[$result['field']] = $result['value'];
}

?>