<?php
/**
 *
 * @ Author Name  : DoiZece
 * @ Release on : 2014-12-28
 * @ Author Website  : http://www.buxsense.ro
 *
 **/

session_start();
define("EvolutionScript", 1);
require_once "./includes/init.php";
?>