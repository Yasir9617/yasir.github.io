<?php
/**
 *
 * @ Author Name  : DoiZece
 * @ Release on : 2014-12-28
 * @ Author Website  : http://www.buxsense.ro
 *
 **/

if (!defined("EvolutionScript")) {
	exit("Hacking attempt...");
}

require SMARTYLOADER;
$smarty->assign("show_leftmenu", "no");
$smarty->assign("yesterday", strtotime("-1 day"));
$smarty->assign("user_group", $user_group);
$smarty->assign("uri", "forum.php?");
?>